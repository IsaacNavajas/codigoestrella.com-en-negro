
<?php
//./Operations.php
class Operations{
    public function __constructor(){

    }

    public function sum($n1, $n2){
        if($n1 == null || $n2 == null) throw new InvalidArgumentException('values are not numeric');
        return $n1 + $n2;
    }

    public function division($n1, $n2){
        return $n1 / $n2;
    }

}


?>

