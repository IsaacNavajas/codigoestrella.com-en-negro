import React from 'react';
import ReactDOM from 'react-dom';
import './Ropa';

function Modal(props){
    if(props.isOpen === false){ return null }
    return ReactDOM.createPortal(
        <div class="model" tabindex="-1" role="dialog">

            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <button type="button" onClick={props.onClose} class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                {props.Children}
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Save changes</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
        ,document.getElementById('model')
    )
}

export default Modal;