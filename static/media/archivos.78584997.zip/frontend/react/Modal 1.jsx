import React from 'react';
import Modal from './Modal';
import OFERTA from './galeria/barradeoferta/OFERTA.png';

class Ropa extends React.Component{
    state={abrirModal:false}
    cerrarModal =() => { this.setState({abrirModal:false})}
    abrirModal = () => { this.setState({abrirModal:true})}

    render(){
        return(
            <React.Fragment>
                <div className="rebajas col-12">
                   <p className="textoRebajas">Este mes rebajas de primavera! Disfrutalas.</p> 
                </div>

                <div className="margendelnavbar col-12">
                    <div className="row">
                        <div className="col-1 col-sm-3"></div>
                            <div className="col-10 col-sm-6">
                                <div className="col-12 col-md-12 col-sm-12 col-lg-6">
                                    <div>
                                        <img
                                        onClick={this.abrirModal}
                                        className="fotoscatalogo"
                                        src={imagencuatro}
                                        alt="imagen"/>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>

                <Modal
                    isOpen={this.state.abrirModal}
                    onClose={this.cerrarModal}>
                        <p>Ácercate a nuestra tienda</p>
                    </Modal>
            </React.Fragment>
        )
    }
}